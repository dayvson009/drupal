Views Isotope
-------------
Views Isotope is a views style plugin that allows views to return results as jQuery Isotope styled structure.

## Dependencies
* views
* jquery_update
* libraries

## Installation
* Download the latest version of [jquery.isotope.min.js][jquery.isotope]
* Place jquery.isotope.min.js in sites/all/libraries/jquery.isotope/

### Note
The D7 version of this module was based on a D6 version found in @funkym's sandbox
The D6 code was build using methods borrowed from views_cycle

[jquery.isotope]: http://isotope.metafizzy.co/jquery.isotope.min.js
[views_cycle]: http://drupal.org/project/views_cycle